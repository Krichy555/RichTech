<?php 
    require_once('../class/AddUser.php');
    $items = $item->all_items();
    // echo '<pre>';
    //     print_r($items);
    // echo '</pre>';
 ?>
<br />
<div class="table-responsive">
        <table id="myTable-item" class="table table-bordered table-hover table-striped">
            <thead>
                <tr>
                    <th>User Id</th>
                    <th>Name</th>
                    <th>Username</th>
                    <th>
                        <center>Action</center>
                    </th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($items as $it): ?>
                    <tr align="center">
                        <td align="left"><?= $it['name']; ?></td>
                        <td align="left"><?= ucwords($it['user_account']); ?></td>
                        <td align="left"><?= $it['user_pass']; ?></td>
                        
                        <td>
                           <center>
                               <button onclick="editModal('<?= $it['user_account']; ?>');" type="button" class="btn btn-warning btn-xs">Edit
                                <span class="glyphicon glyphicon-edit" aria-hidden="true"></span>
                                </button>
                           </center>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
</div>


<br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
<br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />

<!-- for the datatable of employee -->
<script type="text/javascript">
    $(document).ready(function() {
        $('#myTable-item').DataTable();
    });
</script>

<?php 
$item->Disconnect();
 ?>