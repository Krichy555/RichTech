<?php 
interface iAddUser{
	public function all_users();
	public function get_user($user_id);
	public function add_user($iName, $iUsername, $Password);
	public function edit_user($iName, $iUsername, $Password);
}//end iItem