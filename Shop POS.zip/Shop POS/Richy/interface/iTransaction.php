<?php 
interface iTransaction{
}//end iTransaction