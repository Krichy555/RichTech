<?php
require_once('../database/Database.php');
require_once('../interface/iAddUser.php');
class Item extends Database implements iItem {
	public function all_users()
	{
		$sql = "SELECT *
				FROM user";
		return $this->getRows($sql);
	}//end all_items
	
	public function get_user($item_id)
	{
		$sql = "SELECT *
				FROM user
				WHERE user_id = ?";
		return $this->getRow($sql, [$user_id]);
	}//end edit_item

	public function add_user($iName, $iUsername, $Password)
	{
		$sql = "INSERT INTO user(name, user_account, user_pass, )
				VALUES(?, ?, ?)";
		return $this->insertRow($sql, [$iName, $iUsername, $Password]);
	}//end add_item

	public function edit_user($iName, $iUsername, $Password)
	{
		$sql = "UPDATE user 
				SET name = ?, user_account = ?, user_pass = ?
				WHERE user_account = ?";
		return $this->updateRow($sql, [$iName, $iUsername, $Password]);
	}//end edit_item
}//end class Item

$item = new Item();

/* End of file Item.php */
/* Location: .//D/xampp/htdocs/regis/class/Item.php */